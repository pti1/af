docker build --no-cache=true -t pti1/hadoopbase .
