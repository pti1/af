docker build -t pti1/hadoopslave .
