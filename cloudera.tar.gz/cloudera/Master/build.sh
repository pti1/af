docker build -t pti1/hadoopmaster .
